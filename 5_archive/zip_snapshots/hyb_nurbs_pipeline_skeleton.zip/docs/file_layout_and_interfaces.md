# HYB NURBS File Layout and Algorithm Interfaces

This document defines the stable storage layout, naming rules, and algorithm API contracts for the HYB topology-density-to-NURBS pipeline.

The current real ANSYS exports are:

- `D:/Project/3-NetrualDisk/Latest/NLIST.lis`
- `D:/Project/3-NetrualDisk/Latest/export1.txt`

They can remain in place for the current run. Future exported cases should use the case-based layout below so experiments stay reproducible.

## 1. Repository Boundaries

Use three top-level areas:

```text
Latest/
  NLIST.lis                         # current real export, legacy/current shortcut
  export1.txt                       # current real export, legacy/current shortcut
  HYB_NURBS_算法架构说明.md

  hyb_nurbs_pipeline_skeleton/      # source code, configs, tests, docs
    hyb_nurbs/
    configs/
    tests/
    docs/

  data/                             # future canonical input data
  outputs/                          # generated run outputs
  reports/                          # selected human-facing summaries
```

Rules:

- Source code and reusable configuration live under `hyb_nurbs_pipeline_skeleton/`.
- Raw ANSYS exports live under `data/raw/` for future cases.
- Generated files live under `outputs/` and should be reproducible from raw inputs and config.
- Curated figures/tables for thesis or presentation use live under `reports/`.
- Do not mix generated artifacts into `hyb_nurbs/`, `configs/`, or `tests/`.

## 2. Canonical Data Layout

Future cases should be stored as:

```text
data/
  raw/
    hyb_0001_baseline/
      NLIST.lis
      export1.txt
      manifest.yaml
      notes.md
    hyb_0002_eta_sweep/
      NLIST.lis
      export1.txt
      manifest.yaml
      notes.md

  processed/
    hyb_0001_baseline/
      merged_node_density.parquet
      section_cloud.parquet
      boundary_loops.parquet
```

`manifest.yaml` should capture provenance:

```yaml
case_id: hyb_0001_baseline
source: ansys
node_file: NLIST.lis
density_file: export1.txt
node_count_expected: 1050
density_count_expected: 1050
length_unit: m
density_field: topology_density
exported_at: null
notes: current real HYB export
```

Naming rules:

- Case IDs use `hyb_####_short_name`.
- Raw file names keep the ANSYS/export names: `NLIST.lis`, `export1.txt`.
- If multiple density exports exist, use `density_topology.txt`, `density_smooth.txt`, etc., and record the chosen file in `manifest.yaml`.
- Avoid spaces and non-ASCII in machine-read paths. Chinese is fine in human docs.

## 3. Run Output Layout

Each run gets an immutable run directory:

```text
outputs/
  hyb_0001_baseline/
    run_20260508_091200_eta050_tri_iso/
      config_resolved.yaml
      run_manifest.json

      tables/
        merged_node_density.csv
        section_cloud.csv
        boundary_points.csv
        fit_metrics.csv

      geometry/
        boundary_loops.json
        nurbs_fit_results.json
        sampled_boundary.csv
        sampled_nurbs.csv

      figures/
        density_cloud.png
        boundary_overlay.png
        nurbs_fit_overlay.png
        fit_error_heatmap.png

      cad/
        sampled_section_for_apdl.mac
        revolved_surface.stl
        section_curves.step
        section_curves.iges

      logs/
        pipeline.log
        validation_report.json
        warnings.json
```

Current implementation still writes flat files to `outputs/run_001/`. The next pipeline cleanup should switch to the nested layout above.

Run directory naming:

```text
run_YYYYMMDD_HHMMSS_eta{eta*100:03d}_{boundary_method}
```

Examples:

- `run_20260508_091200_eta050_tri_iso`
- `run_20260508_101530_eta045_grid_iso`

Generated file naming:

- CSV tables use snake_case: `section_cloud.csv`, `fit_metrics.csv`.
- JSON geometry/spec files use snake_case: `nurbs_fit_results.json`.
- Images use snake_case and describe the visible layer: `boundary_overlay.png`.
- CAD/FEA exports include the target format: `sampled_section_for_apdl.mac`, `revolved_surface.stl`.

## 4. Pipeline Stage Contracts

The pipeline should remain stage-based. Every stage consumes a dataclass and returns a dataclass or list of dataclasses.

```text
ANSYS files
-> NodeDensityTable
-> SectionCloud
-> list[BoundaryLoop]
-> list[BoundaryLoop] after cleanup/resampling
-> list[FitResult]
-> exported files
```

### 4.1 IO Interface

Module: `hyb_nurbs.io.ansys`

```python
def parse_nlist(path: str | Path) -> pd.DataFrame:
    """Return columns: node_id, x, y, z in input units."""

def parse_density(path: str | Path) -> pd.DataFrame:
    """Return columns: node_id, rho."""

def load_node_density(
    node_file: str | Path,
    density_file: str | Path,
    *,
    scale_to_mm: bool = True,
) -> NodeDensityTable:
    """Inner-join by node_id, reject mismatches, return coordinates in mm."""
```

Validation requirements:

- `node_id` unique in both files.
- Node and density IDs exactly match.
- Current real files must parse as 1050 nodes and 1050 densities.
- Coordinates are converted from m to mm when `scale_to_mm=True`.

### 4.2 Projection Interface

Module: `hyb_nurbs.preprocess.projection`

```python
def project_to_section(
    table: NodeDensityTable,
    axes: tuple[str, str] = ("x", "z"),
    thickness_axis: str = "y",
    mode: Literal["aggregate", "slice"] = "aggregate",
    slice_y: float | None = None,
    aggregate_density: Literal["max", "mean", "median"] = "max",
    rounding_digits: int = 8,
) -> SectionCloud:
    """Return an X-Z section cloud with source node traceability."""
```

Policies:

- Default section axes are `("x", "z")`.
- Default thickness axis is `y`.
- Default mode is `aggregate`.
- Default density aggregation is `max`.
- `source_node_ids` must preserve which 3D nodes formed each section point.

### 4.3 Boundary Extraction Interface

Module: `hyb_nurbs.boundary.iso`

```python
def extract_iso_contours_tri(
    cloud: SectionCloud,
    eta: float = 0.5,
    min_points: int = 20,
) -> list[BoundaryLoop]:
    """Extract rho=eta using Delaunay triangles and linear edge interpolation."""

def extract_iso_contours_grid(
    cloud: SectionCloud,
    eta: float = 0.5,
    grid_resolution_mm: float = 0.15,
) -> list[BoundaryLoop]:
    """Fallback grid interpolation plus marching squares."""

def extract_alpha_shape_boundary(
    cloud: SectionCloud,
    eta: float = 0.5,
    alpha: float | None = None,
) -> list[BoundaryLoop]:
    """Debug fallback only; not the primary thesis method."""
```

Rules:

- Do not fit all `rho >= eta` nodes directly.
- Primary method is `tri_iso`.
- When material touches the design-domain boundary, close the retained region using interpolated/hull boundary segments.
- If element connectivity is later exported, add a mesh-aware contour interface before CAD export.

### 4.4 Boundary Postprocess Interface

Module: `hyb_nurbs.boundary.postprocess`

```python
def ensure_closed(points: np.ndarray, tolerance: float) -> np.ndarray:
    """Append the first point if needed."""

def classify_and_filter_loops(
    loops: list[BoundaryLoop],
    min_component_area_mm2: float,
    min_hole_area_mm2: float,
) -> list[BoundaryLoop]:
    """Filter small loops and set role to outer or hole."""

def resample_loop_by_arclength(
    loop: BoundaryLoop,
    spacing_mm: float,
) -> BoundaryLoop:
    """Return a uniformly sampled closed loop."""
```

Rules:

- Outer loops are CCW.
- Holes are CW.
- Tiny fragments are removed.
- Self-intersecting loops are rejected or reported before fitting.

### 4.5 NURBS/B-Spline Interface

Modules: `hyb_nurbs.nurbs.evaluate`, `hyb_nurbs.nurbs.fitting`

```python
def open_uniform_knot_vector(n_ctrlpts: int, degree: int) -> np.ndarray:
    """Return a clamped open-uniform knot vector."""

def bspline_basis_matrix(
    u: np.ndarray,
    degree: int,
    knots: np.ndarray,
    n_ctrlpts: int,
) -> np.ndarray:
    """Evaluate basis functions with Cox-de Boor recursion."""

def fit_bspline_least_squares(
    points: np.ndarray,
    degree: int = 3,
    n_ctrlpts: int = 12,
    lambda_smooth: float = 1e-4,
    closed: bool = False,
) -> NurbsCurveSpec:
    """Fit a B-spline represented as NURBS with unit weights."""

def refine_fit_until_tolerance(
    loop: BoundaryLoop,
    *,
    degree: int,
    min_ctrlpts: int,
    max_ctrlpts: int,
    initial_control_spacing_mm: float,
    lambda_smooth: float,
    tolerances: dict,
) -> FitResult:
    """Increase control points until error targets pass or max_ctrlpts is reached."""
```

First-stage NURBS policy:

- `degree = 3`
- `weights = 1.0`
- Fit in mm.
- Stop when mean, max, and area errors satisfy config thresholds.

### 4.6 Validation Interface

Module: `hyb_nurbs.validation.metrics`

```python
def polygon_area(points: np.ndarray) -> float:
    """Return absolute polygon area in mm^2."""

def directed_nearest_distances(src: np.ndarray, dst: np.ndarray) -> np.ndarray:
    """Return nearest-neighbor distances from src to dst."""

def evaluate_fit_metrics(
    loop: BoundaryLoop,
    curves: list[NurbsCurveSpec],
    n_eval: int = 1000,
) -> FitMetrics:
    """Return mean, max, Hausdorff, and area error."""
```

Metrics:

- `mean_error_mm`
- `max_error_mm`
- `hausdorff_error_mm`
- `area_error_ratio`
- `n_control_points`
- `n_samples`

### 4.7 Export Interface

Module: `hyb_nurbs.exporters.files`

```python
def write_debug_csv(out_dir: str | Path, table: NodeDensityTable, cloud: SectionCloud) -> None:
    """Write merged node-density and section cloud CSV files."""

def write_json(path: str | Path, payload: Any) -> None:
    """Serialize dataclasses, arrays, and primitive values."""

def write_apdl_polyline_macro(path: str | Path, curves: list[NurbsCurveSpec]) -> None:
    """Write sampled fallback APDL keypoints and lines."""

def write_ascii_stl(path: str | Path, vertices: np.ndarray, faces: np.ndarray) -> None:
    """Write lightweight revolved mesh output."""
```

### 4.8 CAD/Revolve Interface

Module: `hyb_nurbs.cad.revolve`

```python
def revolve_curves_to_surface(
    curves: list[NurbsCurveSpec],
    *,
    axis: str = "z",
    angle_deg: float = 360.0,
    n_sections: int = 96,
) -> dict[str, np.ndarray]:
    """Return vertices and faces for a sampled revolved surface mesh."""
```

Near-term CAD strategy:

- First export sampled STL and APDL macro.
- Then add STEP/IGES via `geomdl` or `pythonocc-core`.
- Keep CAD export disabled unless boundary and fit validation pass.

## 5. Config Design

Keep reusable configs under:

```text
hyb_nurbs_pipeline_skeleton/configs/
  default.yaml
  cases/
    hyb_0001_baseline.yaml
    hyb_0002_eta_sweep.yaml
```

Case config should point to raw data and output root:

```yaml
case:
  case_id: hyb_0001_baseline
  description: current HYB ANSYS topology export

input:
  node_file: data/raw/hyb_0001_baseline/NLIST.lis
  density_file: data/raw/hyb_0001_baseline/export1.txt

export:
  out_root: outputs
  run_name: auto
```

The pipeline should resolve:

```text
out_dir = {out_root}/{case_id}/{run_name}
```

## 6. Run Manifest Design

Each run should write `run_manifest.json`:

```json
{
  "case_id": "hyb_0001_baseline",
  "run_name": "run_20260508_091200_eta050_tri_iso",
  "input_files": {
    "node_file": "data/raw/hyb_0001_baseline/NLIST.lis",
    "density_file": "data/raw/hyb_0001_baseline/export1.txt"
  },
  "counts": {
    "nodes": 1050,
    "densities": 1050,
    "section_points": 673,
    "boundary_loops": 1
  },
  "parameters": {
    "eta": 0.5,
    "projection": "x-z aggregate max",
    "boundary_method": "tri_iso",
    "degree": 3,
    "weights_mode": "fixed_ones"
  },
  "status": "ok"
}
```

## 7. Immediate Next Implementation Tasks

1. Add `case.case_id`, `export.out_root`, and `export.run_name` support to config loading.
2. Make `run_pipeline()` create nested run directories and write `config_resolved.yaml`.
3. Move generated CSV/JSON/PNG/CAD files into `tables/`, `geometry/`, `figures/`, and `cad/`.
4. Write `run_manifest.json` and `validation_report.json`.
5. Add `configs/cases/hyb_0001_baseline.yaml` once the raw files are copied into `data/raw/hyb_0001_baseline/`.
6. Keep the current root-level `NLIST.lis` and `export1.txt` working as a compatibility path until the data migration is done.
