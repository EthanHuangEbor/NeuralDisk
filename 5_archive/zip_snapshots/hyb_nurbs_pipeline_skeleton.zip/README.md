# HYB NURBS reconstruction pipeline skeleton

This repository skeleton is the implementation target for Codex. It converts ANSYS topology density results and node coordinates into a cleaned 2D boundary, fits cubic NURBS curves, validates the fit, and prepares CAD/FEA export hooks.

Current input assumption:
- `NLIST.lis`: ANSYS node coordinate listing with columns `NODE X Y Z`.
- `export1.txt`: node-wise topology density with columns `Node Number` and `Topology Density`.
- Current files contain 1050 nodes and 1050 densities with matching node IDs.

Primary pipeline:

```text
parse ANSYS files
-> join node coordinates and density by node_id
-> project to section plane, normally X-Z
-> aggregate duplicated projected points or select a Y slice
-> interpolate/scatter density field
-> extract iso-density contour at eta, default 0.5
-> filter components and repair loops
-> resample loops by arc length
-> segment by curvature/corners if needed
-> fit degree-3 NURBS/B-spline pieces
-> compute mean/max/Hausdorff/area errors
-> export JSON/CSV/plots/CAD hooks/APDL hooks
```

Codex should implement the TODO blocks module by module, starting from the parser and unit tests.

Planning documents:
- `docs/file_layout_and_interfaces.md`: storage layout, naming rules, run-output layout, and stable algorithm interfaces.
